a = readtable("D:\унік\NASA\NH.Ts+dSST.csv")
%%
M = table2array(a)';
y = M(:);

p = size(y);
p = p(:, 1);
x = 1:p;

plot(x, y)
hold on

valid = ~isnan(y);
[pLinear, SLinear] = polyfit(x(valid), y(valid), 1);

% Обчислюємо координати прямої для всіх x та малюємо її
yFit = polyval(pLinear, x);
plot(x, yFit, 'LineWidth', 2)
hold off